﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WinFormsApp1
{
    public partial class SignUp : Form
    {
        String Name = "", Uname = "", Pass = "", Address = "", Role = "";
        public SignUp()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void go_signin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            Sign_in a = new Sign_in();
            a.Show();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void Sign_in_Click(object sender, EventArgs e)
        {
            if (Name == "")
                Name = textBox1.Text;

            if (Uname == "")
                Uname = textBox2.Text;
            if (Pass == "")
                Pass = textBox3.Text;
            if (Address == "")
                Address = textBox4.Text;
            if (radioButton1.Checked)
                Role = "Employee";
            else if (radioButton2.Checked)
                Role = "Customer";
            else
                MessageBox.Show("Select your Role");


            if (Name != "" || Uname != "" || Pass != "" || Address != "" || Role != "")
            {
                try
                {
                    SqlConnection conn = new SqlConnection(@"Data Source=SYNIXSHERLOCK;Initial Catalog=Farm_Manage;Integrated Security=True");
                    conn.Open();

                    string query = "insert into signupT (Name,Username,Password,Address,role) VALUES('" + Name + "','" + Uname + "','" + Pass + "','" + Address + "','" + Role + "')";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    int result = cmd.ExecuteNonQuery();
                    if (result > 0)
                        MessageBox.Show("User registered successfully");
                    else
                    {
                        MessageBox.Show("Error occured");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
                MessageBox.Show("Provide proper information");
        }
    }
}
