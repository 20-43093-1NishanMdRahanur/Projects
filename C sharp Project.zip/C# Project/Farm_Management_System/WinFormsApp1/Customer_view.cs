﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Customer_view : Form
    {
        public Customer_view()
        {
            InitializeComponent();
        }

        private void Customer_view_Load(object sender, EventArgs e)
        {

        }
    }
}
