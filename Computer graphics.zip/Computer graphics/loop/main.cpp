#include<windows.h>
#include <GL/gl.h>
#include <GL/glut.h>



void myDisplayRectangular(void)
{
glClearColor(1.0f, 1.0f, 1.0f, 0.0f);
glClear(GL_COLOR_BUFFER_BIT);
glLoadIdentity();
gluOrtho2D(0,18,0,10);
glPushMatrix();
glLineWidth(1.5);
glBegin(GL_LINE_STRIP);
{
glColor3f(0.0f,0.0f,0.0f);
glVertex2f(4,2);
glVertex2f(5.76,4);
glVertex2f(7.48,5.2);
glVertex2f(10.24, 5.6);
glVertex2f(12.96,5.2);
glVertex2f(16,4);
glEnd();
}




glPopMatrix();



glEnd();
glFlush ();
}




void myInit (void)
{
glClearColor(1.0, 1.0, 1.0, 0.0);
glColor3f(0.0f, 0.0f, 0.0f);
glPointSize(4.0);
glMatrixMode(GL_PROJECTION);
glLoadIdentity();
gluOrtho2D(0.0, 820.0, 0.0, 568.0);
}



int main(int argc, char** argv)
{
glutInit(&argc, argv);
glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
glutInitWindowSize(1600,960);
glutCreateWindow ("Perabola task");
glutDisplayFunc(myDisplayRectangular);
myInit ();



glutMainLoop();
return 0;
}

