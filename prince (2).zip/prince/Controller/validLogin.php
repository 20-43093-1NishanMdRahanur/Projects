<?php
$username='';
$password='';

session_start();

if(isset($_POST["btnClick"]))
{
	
	if(empty($_POST["username"]))
	{
		$uname="<span style='color:red;'>Please enter your username!</span>";
	}
	else if(empty($_POST["password"])){
	    
		$pass="<span style='color:red;'>Please enter your password!</span>";	
	}
		
    else{
			$formdata = array(
				'Username'=>$_POST["username"],
				'Password'=> $_POST["password"]	
			 );

			 $existingdata = file_get_contents('../model/data.json');
			 $tempJSONdata = json_decode($existingdata);
			 $tempJSONdata[] =$formdata;
			
			 $jsondata = json_encode($tempJSONdata, JSON_PRETTY_PRINT);
			 
			 
			 if(file_put_contents("../model/data.json", $jsondata)) {
				
			  }
			 else{ 
				  echo "no data saved";
		
		   $data = file_get_contents("../model/data.json");		   
		
		}
	
		$_SESSION["username"] = $_POST['username'];
		
		header("location:manager_dashboard.html");

	}
}
		
?>

