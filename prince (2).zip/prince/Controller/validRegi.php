<?php
$fname = $lname =$gender = $dob= $religion = $praddress = $pmaddress = $phone = $email =  $username = $password = $confirmpassword = "";

if (isset($_POST['submit'])) {
	if (empty($_POST['fname'])) {
        $fname= "<span style='color:red;'>Required</span>";
		}
    }
if (isset($_POST['submit'])) {
    if(empty($_POST['lname'])){
			$lname= "<span style='color:red;'>Required</span>";	
		}
    }
if (isset($_POST['submit'])) {
        if(empty($_POST['gender'])){
                $gender= "<span style='color:red;'>Required</span>";	
            }
        }
if (isset($_POST['submit'])) {
            if(empty($_POST['dob'])){
                    $dob= "<span style='color:red;'>Required</span>";	
                }
            }
if (isset($_POST['submit'])) {
                if(empty($_POST['religion'])){
                        $religion= "<span style='color:red;'>Required</span>";	
                    }
                }
if (isset($_POST['submit'])) {
                    if(empty($_POST['praddress'])){
                            $praddress= "<span style='color:red;'>Required</span>";	
                        }
    }
if (isset($_POST['submit'])) {
        if(empty($_POST['pmaddress'])){
                $pmaddress= "<span style='color:red;'>Required</span>";	
            }
}
if (isset($_POST['submit'])) {
    if(empty($_POST['phone'])){
            $phone= "<span style='color:red;'>Required</span>";	
        }
}
if (isset($_POST['submit'])) {
    if(empty($_POST['email'])){
        $email= "<span style='color:red;'>Required</span>";
    }
}

if (isset($_POST['submit'])) {
    if(empty($_POST['username'])){
            $username= "<span style='color:red;'>Required</span>";
        }
    }

if (isset($_POST['submit'])) {
        if(empty($_POST['password'])){
            $password= "<span style='color:red;'>Required</span>";
        }
    }
if (isset($_POST['submit'])) {
        if(empty($_POST['confirmpassword'])){
            $confirmpassword= "<span style='color:red;'>Required</span>";
        }
    
		else{
            
			$formdata = array(
				'FirstName'=>$_POST["fname"],
                'LastName'=>$_POST["lname"],
                'Gender'=>$_POST["gender"],
                'Date of Birth'=>$_POST["dob"],
                'Religion'=>$_POST["religion"],
                'Present Address'=>$_POST["praddress"],
                'Parmanant Address'=>$_POST["pmaddress"],
                'Phone'=>$_POST["phone"],
                'Email'=>$_POST["email"],
                'Username'=>$_POST["username"],
                
				'Password'=> $_POST["password"],
                'Confirm Password'=>$_POST["confirmpassword"]
			 );
			 $existingdata = file_get_contents('../model/data2.json');
			 $tempJSONdata = json_decode($existingdata);
			 $tempJSONdata[] =$formdata;
			 
			 $jsondata = json_encode($tempJSONdata, JSON_PRETTY_PRINT);
			 
			 
			 if(file_put_contents("../model/data2.json", $jsondata)) {
				  
			  }
			 else 
				  echo "no data saved";
		
		   $data = file_get_contents("../model/data2.json");

        //    header("location:../view/homepage.php");
		
		}
	}
 
?>

