<?php
include("../controller/validLogin.php");
if(!empty($_POST["username"])) {
	setcookie ("username",$_POST["username"],time()+ (86400 * 30), "/");
	
   $userid=$_POST["username"];
} 
else {
	setcookie("username","");
	
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>LOGIN</title>
    <style>
        .top 
        {
            text-align: center;
        }
        .center 
        {
            text-align: center;
        }
    </style>
</head>
<body>
<div class="center">
<form action="<?php echo $_SERVER["PHP_SELF"];?>" method="POST" style="display: inline-block;" >  
    <h1 class="top"> PHARMACY MANAGEMENT SYSTEM </h1>
    <hr>
	<br>
    <div class="center">
    <fieldset>
        <label style="font-size:20px;"><strong>Login Here</strong></label>
        <br>
        <div class="center">
        <label for="username">Username : </label>
        <br>
        <input type="text" id="username" name="username" >
        </input>
        <br><br> 
        </div>
        <div class="center">
        <label for="password">Password : </label>
        <br>
        <input type="password" id="password" name="password" >
        </input>
        <br>
        </div>
        </fieldset> 
        <br>
        <div class="center">
        <input type="submit" value="Login" name="btnClick"><br>
        <br>
        </div>
        <div class="center">
        <a href="forget_password.html">Forget Password ? </a> 
        </div>
        <a href="homepage.php">Go Back to Home Page</a>
        </div>
</form>   
</body>
</html>