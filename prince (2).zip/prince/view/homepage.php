<!DOCTYPE html>
<html>
<head>
    <title>LOGIN</title>
    <style>
        .top 
        {
            text-align: center;
        }
        .center 
        {
            text-align: center;
        }
    </style>
</head>
<body>
    <br><br><br>
    <fieldset>
    <div class="center">
        <form action="login.html" method="POST" style="display: inline-block;" >  
            <h1 class="top"> PHARMACY MANAGEMENT SYSTEM </h1>
            <hr>
            <br><br><br><br>
            <h2 class="top"> WELCOME </h2>
            <hr>
            <div>
<h3 class="top"><a href="../view/Login2.php">Login</a></h3>
<h2><a> Or </a></h2>
<h3 class="top"><a href="../view/Registration2.php">Registration</a></h3>
</div>
    </fieldset>
</body>
</html>