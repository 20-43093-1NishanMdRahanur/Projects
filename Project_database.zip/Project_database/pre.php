<?php 
    session_start();
    if(isset($_SESSION['flag']))
    {
        
?>

<html>
    <head>
        <title>Log in</title>
    </head>

    <body>

        <form method="POST" action="LoggedinCheck.php" enctype="">
        <table border="1">
<tr>
    <td style="width: 300px">
    <img align="left" src="X_company.png" width="30" height="30"/>
    Welcome to Course Registration management system. <br>
         <div style="float: right;">
     Loggedin as <a href="View_profile.php" style="font-size: 10px"><?php echo $_SESSION['username']?></a>|
        <a href="logout.php" style="font-size: 10px">Logout</a>
     </div>    </td>
</tr>
<tr><td align="left" style="height:200">
           
                <table>
                    <tr>
                        <td>
                <tr><td> Account <hr></td></tr>
                <tr><td>
                <a href="Dashboard.php">Dashboard</a><br>
                <a href="View_profile.php">View Profile</a><br>
                <a href="change_pass.php">Change Password</a><br>
                <a href="Searching.php">Searching</a>  <br>
                <?php
                if($_SESSION['user']=="Doctor")
                {
                    ?>
                    <html>
                        <body>
                        <a href="Searching.php">Prerequisite</a>  <br>
                        </body>
                    </html>
                    <?php
                }
                ?>
                <a href="logout.php">Log Out</a></td></tr>
</td>
               </tr>
                </table>

            </td>
            <td> <fieldset style="width:300px">
                <legend>Prerequisite</legend>
                <table>
                    <tr>
                        <td>
<table border="1">
              <tr><td>Course Name</td><td>Course Id</td><td>Prerequisite course</td></tr>

                <tr><td>C++</td><td>101</td><td>C</td></tr>
                <tr><td>Java</td><td>102</td><td>C++</td></tr>
                <tr><td>Math-1</td><td>103</td><td>C</td></tr>
                <tr><td>Math-2</td><td>104</td><td>Math-1</td></tr>
                <tr><td>Math-3</td><td>105</td><td>Math-2</td></tr>
                <tr><td>Math-4</td><td>106</td><td>Math-3</td></tr>

               </table>
               <table>
               <!-- <tr><td><input type="submit" name="Search" value="Back"/></td><td> </td></tr> -->
               </table>
</td>
               </tr>
                </table>

            </fieldset></td>

        </tr>

</table>  
</form>  

    </body>
</html>
<?php
}
?>