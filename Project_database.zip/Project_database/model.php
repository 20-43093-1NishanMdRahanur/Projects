<?php

   include("db.php");
   $conn= ocilogon($user,$pass,$db);
   if(!$conn){
    echo "Connection is invalid ".var_dump ( OCIError() );
    die();
}
   function registration($name,$username,$password,$email,$gender,$date,$image,$select_user)
   {
    $query="insert into registration values ('$name', '$username','$password','$email','$gender','$date','$image','$select_user')";
    $execute = oci_parse($conn, $query); // using oci_parse instead of ($conn,$query)
    oci_execute($execute, OCI_DEFAULT); // using oci_execute instead of OCIExecute
    oci_commit($conn); // using oci_commit instead of OCICommit
    oci_close($conn); // using oci_close instead of OCILogoff
   }

?>