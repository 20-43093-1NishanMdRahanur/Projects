<?php 
    session_start();
              
   
    if(isset($_REQUEST['submit_change_picture']))
    {
      
     $filename= $_REQUEST['file'];
     if($filename!="")
    {
  


      $username = $_SESSION['username']; 
      $password = $_SESSION['password']; 
    $flag = false; 
    $updated_user_data = array();
   $file = fopen('user.txt', 'r');

   if ($file) {
         while (($line = fgets($file)) !== false) {
               $user = explode('=', $line);
                if(trim($user[1]) == $username && trim($user[2]) == $password) {
                        $flag = true; 

                        $user[9] = $filename;
                      
                         $_SESSION['image2'] = trim($user[9]);
                       
                           $updated_user_data[] = implode("=", $user);
                           break;
                  }
                  else {
                    // Add the unmodified line to the array
                    $updated_user_data[] = $line;
                }
              }
          }
          fclose($file);

        if($flag) {
          setcookie('flag', 'abc', time()+1000000, '/');
         $file = fopen('user.txt', 'w');

           foreach ($updated_user_data as $line) {
           fwrite($file, $line);
          }


      if(trim($user[9])=="")
      {
        $user[10]=$user[8];
      }
      elseif(trim($user[9])!="")
      {
        $user[10]=$user[9];
      }
      $_SESSION['image']=trim($user[10]);
     ?> <html><body>
      Profile Picture updated
      <a href="change_profile.php">Back</a>
     </body></html><?php
    }
    else
    {
    
    ?> <html><body>
     Please Select a file
     <a href="change_profile.php">Back</a>
    </body></html><?php
    }
    }
  }
               elseif(isset($_REQUEST['Dashboard']))
              {

                $_SESSION['flag'] = "true";
               // $file = fopen('user.txt', 'r');
                   
                  //while(!feof($file))
                   //{
                       /*$data = fgets($file);
                       $user = explode('|', $data);
                       //print_r($user);
                       if($username == trim($user[1]) && $password == trim($user[2]))
                       {
                           $flag = true; 
                           $_SESSION['Name']=trim($user[0]);
                       }*/
                         header('location: Dashboard.php');
                   // }
                   // fclose($file);
                }
              elseif(isset($_REQUEST['View_Profile']))
              {
           
                $_SESSION['flag'] = "true";
                
                header('location: View_profile.php');
              }
              elseif(isset($_REQUEST['Edit_Profile'])) 
              {
                $_SESSION['flag'] = "true";
                header('location: edit_profile.php');
              

              }
              elseif(isset($_REQUEST['Edit_submit']))
              {
               

                $username = $_SESSION['username']; 
                    $password = $_SESSION['password']; 
                  $flag = false; 
                  $updated_user_data = array();
                 $file = fopen('user.txt', 'r');

                 if ($file) {
                       while (($line = fgets($file)) !== false) {
                             $user = explode('=', $line);
                              if(trim($user[1]) == $username && trim($user[2]) == $password) {
                                      $flag = true; 

                                      $user[0] = $_REQUEST['Change_name'];
                                      $user[3] = $_REQUEST['Change_email'];
                                      $user[5] = $_REQUEST['Change_gender'];
                                      $user[6] = $_REQUEST['change_date'];

                                       $_SESSION['Name'] = trim($user[0]);
                                         $_SESSION['email'] = trim($user[3]);
                                          $_SESSION['gender'] = trim($user[5]);
                                         $_SESSION['date'] = trim($user[6]);
                                         $updated_user_data[] = implode("=", $user);
                                         break;
                                }
                                else {
                                  // Add the unmodified line to the array
                                  $updated_user_data[] = $line;
                              }
                            }
                        }
                        fclose($file);

          if($flag) {
             setcookie('flag', 'abc', time()+1000000, '/');
             $file = fopen('user.txt', 'w');

             foreach ($updated_user_data as $line) {
             fwrite($file, $line);
            }
             
            // header('location: Logged_in_user.php');
        } 
        else {
             echo 'Invalid username or password';
             }
             fclose($file);


                ?>
                <html><body>
                Profile information update successfully <a href="edit_profile.php">Back</a>
                </body></html>

                <?php



              }
              
              elseif(isset($_REQUEST['Term_edit']))
              {
                
                $_SESSION['flag'] = "true";
                $_SESSION['tedit']="on";
                
                header('location: Term_conditin.php');

              } 

              elseif(isset($_REQUEST['Term_back']))
              {
                
                $_SESSION['flag'] = "true";
                
                header('location: Public_user.php');

              } 

              elseif(isset($_REQUEST['Change_profile_picture'])) 
              {

                $_SESSION['flag'] = "true";
                
                header('location: change_profile.php');
              
              }
              elseif(isset($_REQUEST['Change_password'])) 
              {
                $_SESSION['flag'] = "true";
                
                header('location: change_pass.php');
              

              }
              elseif(isset($_REQUEST['Log_out'])) 
              {
                $_SESSION['flag'] = "true";
                
                header('location: logout.php');
              

              }
              elseif(isset($_REQUEST['searching'])) 
              {
                $_SESSION['flag'] = "true";
                
                header('location: searching.php');
              

              }
              elseif(isset($_REQUEST['rating_submit']))
              {
                $rating=$_REQUEST['rating'];
                setcookie("doctor_rating", $rating, time() + 120, "/");
                 ?>
                 <html>
                  <body>
                    Rating Submitted <a href="Logged_in_user.php">Back</a>
                  </body>
                 </html>
                 <?php
              }
              elseif(isset($_REQUEST['search_doctor'])) 
              {
                $username=$_REQUEST['Doctor_username'];
                $_SESSION['flag'] = "true";
                $flag = false; 
                $file = fopen('user.txt', 'r');
   
                if ($file) {
                 while (($line1 = fgets($file)) !== false) {
                   $user = explode('=', $line1);
                   if(trim($user[8]!='Doctor'))
                   {            
                      header('location: Doctor_profile.php?Error=user');
                   }
                   elseif(trim($user[1])==$username)
                   {
                        $flag=true;

                        $_SESSION['doctor_Name']=trim($user[0]);
                        $_SESSION['doctor_email']=trim($user[3]);
                        $_SESSION['doctor_gender']=trim($user[5]);
                        $_SESSION['doctor_date']=trim($user[6]);
                        $_SESSION['doctor_image1']=trim($user[9]);
                        $_SESSION['doctor_image2']=trim($user[10]);
                        $_SESSION['doctor_image']=trim($user[11]);
                        if(isset($_COOKIE['doctor_rating']))
                        {
                          $_SESSION['doctor_rating']=$_COOKIE['doctor_rating'];
                        }
                        else
                        {
                          $_SESSION['doctor_rating']="Don't have any rating yet";
                        }
                        if(trim($user[9])=="")
                        {
                           $user[10]=$user[8];
                           $_SESSION['doctor_image']=trim($user[8]);
                        }
                        else
                        {
                           $user[10]=$user[9];
                           $_SESSION['doctor_image']=trim($user[9]);
                        }



                   }
                   
                              
                   }
                   if($flag!=true)
                   {
                    header('location: Doctor_profile.php?Error=username');
                  }
                   else
                   {
                    $flag=false;
                    header('location: Doctor_profile_view.php');
                   }
                }
               // header('location: Doctor_profile.php');
              

              }
              elseif(isset($_REQUEST['Back_article']))
              {
                
                $_SESSION['flag'] = "true";
                
                header('location: article_profile.php');
              }
              elseif(isset($_REQUEST['send_request']))
              {
                 if($_REQUEST['Appointment_date']==""|| $_REQUEST['Appointment_time']=="")
                 {
                  ?>
                  <html>
                    <body>
                      
                    Enter date and time currectly <a href="patient_appointment.php">Back</a>
                    </body>
                  </html>
                  <?php
                 }
                 else
                 {
                 
                  if(isset($_COOKIE['confirm_request']))
                  {
                    ?>
                    <html>
                      <body>
                       You Already have a appointment with <?php echo $_SESSION['doctor_Name'] ?>. <a href="patient_appointment.php">Back</a>
                      </body>
                    </html>
                    <?php
                  }
                  elseif(isset($_COOKIE['Appointment_date']))
                  {
                    ?>
                    <html>
                      <body>
                       You Already have a pending request. <a href="patient_appointment.php">Back</a>
                      </body>
                    </html>
                    <?php
                  }
                 else
                 {
                  $_SESSION['Appointment_date']=$_REQUEST['Appointment_date'];
                  $_SESSION['Appointment_time']=$_REQUEST['Appointment_time'];
                  $check_date=$_REQUEST['Appointment_date'];
                  $check_time=$_REQUEST['Appointment_time'];
                  $check_name=$_SESSION['Name'];
                  $check_date = date('d/m/Y', strtotime($check_date));
                  $check_time = date('g:i A', strtotime($check_time));
                  setcookie("Appointment_date", $check_date, time() + 500, "/");
                  setcookie("Appointment_time", $check_time, time() + 500, "/");
                  setcookie("Patient_name", $check_name, time() + 500, "/");
                  ?>
                  <html>
                    <body>
                     Request sent to the doctor. Please wait untill doctor's response. <a href="patient_appointment.php">Back</a>
                    </body>
                  </html>
                  <?php
                 }
                 // echo $check_date."    ".$check_time."        ".$check_name;
                 }
              }
              elseif(isset($_REQUEST['Review_request']))
              {
                
                
                header('location: Doctor_appoint.php');
              
              }
              elseif(isset($_REQUEST['Review_Reject_request']))
              {
               if(isset($_COOKIE['Appointment_date']))
               {
                setcookie("Appointment_date", $_SESSION['Appointment_date'], time() - 500, "/");
                setcookie("Appointment_time", $_SESSION['Appointment_time'], time() - 500, "/");
                setcookie("Patient_name", $_SESSION['Name'], time() - 500, "/");
                setcookie("reject_request", "Reject", time() + 500, "/");
                ?>
                <html>
                  <body>
                   Appointment Rejected. <a href="Logged_in_user.php">Back</a>
                  </body>
                </html>
                <?php
               }
               else
               {
                ?>
                <html>
                  <body>
                   Invalid date and time. <a href="Logged_in_user.php">Back</a>
                  </body>
                </html>
                <?php          
               }
              }






              elseif(isset($_REQUEST['Review_confirm_request']))
              {
               if(isset($_COOKIE['Appointment_date']))
               {
                setcookie("Appointment_date", $_SESSION['Appointment_date'], time() - 500, "/");
                setcookie("Appointment_time", $_SESSION['Appointment_time'], time() - 500, "/");
                setcookie("Patient_name", $_SESSION['Name'], time() - 500, "/");
                setcookie("confirm_request", "confirm", time() + 500, "/");
                ?>
                <html>
                  <body>
                   Appointment Confirmed. <a href="Logged_in_user.php">Back</a>
                  </body>
                </html>
                <?php
               }
               else
               {
                ?>
                <html>
                  <body>
                   Invalid date and time. <a href="Logged_in_user.php">Back</a>
                  </body>
                </html>
                <?php          
               }
              }


              elseif(isset($_REQUEST['search_article']))
              {
                $article=$_REQUEST['article_title'];
                $file = fopen('article.txt', 'r');
                $flag=false;
                while (($line = fgets($file)) !== false) {
                  $user = explode('|', $line);
                  if(trim($user[0]) == $article) {
                     $flag=true;
                  }
                
                }
                if($flag)
                {
                  $flag=false;
                  $_SESSION['found_article']=$article;
                 echo"found".$article;
                
                header('location: article_link.php');
                }
                elseif($article=="")
                {
                  ?>
                  <html>
                   <body>
                   Blank Value <a href="article_profile.php">Back</a>
                   </body>
                  </html>
                  <?php
                }
                else
                {
                 ?>
                 <html>
                  <body>
                  Sorry, We have no article of this name <a href="article_profile.php">Back</a>
                  </body>
                 </html>
                 <?php
                }
              }
              elseif(isset($_REQUEST['Search']))
              {
                      $filter=$_REQUEST['Filter'];
                      if($filter=='Doctor')
                      {
                        
                          header('location: Doctor_profile.php');
                          
                        
                      }
                      elseif($filter=='Article')
                      {
                        header('location: article_profile.php');
                      }
                      else
                      {
                        ?>
                        <html>
                          <body>
                            Select what you want to search<a href="searching.php">Back</a>
                          </body>
                        </html>
                        <?php
                      }
              } 
              elseif(isset($_REQUEST['submit_change_password']))
              {
                $password=$_REQUEST['password'];
                $newpassword=$_REQUEST['new_password'];
                $retype=$_REQUEST['retype_new_password'];
                if($newpassword!=$retype)
                {
                  ?>
                  <html>
                    <body>
                      Pasword are not match. Please enter same password to the new Pasword and retype password.<a href="change_pass.php">Back</a>
                    </body>
                  </html>
                  <?php
                }
                elseif($newpassword=="")
                {
                  ?>
                  <html>
                    <body>
                      Pasword can't be blanked.<a href="change_pass.php">Back</a>
                    </body>
                  </html>
                  <?php
                }
                
                else
                {
                 // $_SESSION['password']=$newpassword;
                 // $_SESSION['Confirm_password']=$retype;
                 


                 $username = $_SESSION['username']; 
                 $password = $_SESSION['password']; 
              $flag = false; 
              $updated_user_data = array();
             $file = fopen('user.txt', 'r');

             if ($file) {
                   while (($line1 = fgets($file)) !== false) {
                         $userp = explode('=', $line1);
                         if($newpassword==trim($userp[2]))
                {
                  ?>
                  <html>
                    <body>
                      You Enter your previous password. Check Again.<a href="change_pass.php">Back</a>
                    </body>
                  </html>
                  <?php
                }
                          elseif(trim($userp[1]) == $username && trim($userp[2]) == $password) {
                                  $flag = true; 

                                  $userp[2] = $newpassword;
                                  $userp[4] = $retype;
                                
                                   $_SESSION['password'] = trim($userp[2]);
                                     $_SESSION['Confirm_password'] = trim($userp[4]);
                                     $updated_user_data[] = implode("=", $userp);
                                     break;
                            }
                            elseif(trim($userp[1]) == $username && trim($userp[2]) != $password)
                            {
                              ?>
                              <html>
                                <body>
                                  Incorrect Password<a href="change_pass.php">Back</a>
                                </body>
                              </html>
                              <?php
                            }
                            
               

                            else {
                              $updated_user_data[] = $line1;
                          }
                        }
                    }
                    fclose($file);
      if($flag) {
         setcookie('flag', 'abc', time()+1000000, '/');
         $file = fopen('user.txt', 'w');

         foreach ($updated_user_data as $line1) {
         fwrite($file, $line1);
         fclose($file);

        }


                  ?>
                  <html>
                    <body>
                      Your Password Change successfully<a href="change_pass.php">Back</a>
                    </body>
                  </html>
                  <?php
                }
              }
            }
           
        else
        {
                 echo "invalid request...";
        }
?>