<?php
$user="system";
$pass="1234";
$db="xe";
?>