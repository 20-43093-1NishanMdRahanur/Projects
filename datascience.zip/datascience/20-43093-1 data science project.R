#Perform the dataset
nishan <- read.csv("D:/datascience/fastfood.csv",header=TRUE,sep=",")

remove<-na.omit(nishan)

scaled_data <- scale(nishan)
k<-2

# Finding  the optimal number of clusters using the elbow method
wss <- NULL
for (i in 1:10) {
  kmeans_fit <- kmeans(nishan, centers = i, nstart = 10)
  wss[i] <- kmeans_fit$tot.withinss
}
plot(1:10, wss, type = "b", xlab = "Number of clusters", ylab = "Within-cluster sum of squares")


#Perform k-means clustering with 3 clusters
kmeans_fit <- kmeans(nishan, centers = 3, nstart = 10)

# To show the cluster assignments
kmeans_fit$cluster

kmeans_result<- kmeans(scaled_data,k)
fviz_cluster(kmeans_result,data=scaled_data)